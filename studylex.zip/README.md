# Study Buddy  

## Publishing instructions

Follow the link below to publish a test build. However, make the following changes:

1. Zip the entire contents of the folder into a zip (DO NOT zip the folder, instead zip the items themselves -- so when you open up the zipped folder, the items are at the top level). DO NOT check this into source control (if you name it studybuddy.zip, it will be .gitignored). 

https://developer.amazon.com/public/community/post/Tx3DVGG0K0TPUGQ/New-Alexa-Skills-Kit-Template:-Step-by-Step-Guide-to-Build-a-Fact-Skill

